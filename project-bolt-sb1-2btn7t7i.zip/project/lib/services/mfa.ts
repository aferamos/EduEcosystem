import { supabase } from '@/lib/supabase';

export interface MFAState {
  totpEnabled: boolean;
  methodPreference: 'none' | 'totp' | 'sms' | 'email';
  verifiedAt: string | null;
}

export async function getMFAState(userId: string): Promise<MFAState | null> {
  const { data, error } = await supabase
    .from('user_mfa')
    .select('totp_enabled, method_preference, totp_verified_at')
    .eq('user_id', userId)
    .maybeSingle();
  if (error || !data) return null;
  return {
    totpEnabled: data.totp_enabled,
    methodPreference: data.method_preference,
    verifiedAt: data.totp_verified_at,
  };
}

export async function setupTOTP(userId: string): Promise<{ secret: string; uri: string } | null> {
  const { data, error } = await supabase.rpc('generate_totp_secret', { user_id: userId });
  if (error || !data) return null;
  return { secret: data.secret, uri: data.uri };
}

export async function verifyAndEnableTOTP(userId: string, code: string): Promise<boolean> {
  const { data, error } = await supabase.rpc('verify_totp_code', { user_id: userId, code });
  if (error || !data) return false;
  return data.success;
}

export async function disableMFA(userId: string): Promise<void> {
  const { error } = await supabase
    .from('user_mfa')
    .update({ totp_enabled: false, totp_secret: null, method_preference: 'none' })
    .eq('user_id', userId);
  if (error) throw new Error(error.message);
}

export async function setMFAPreference(userId: string, method: 'none' | 'totp' | 'sms' | 'email'): Promise<void> {
  const { error } = await supabase
    .from('user_mfa')
    .update({ method_preference: method })
    .eq('user_id', userId);
  if (error) throw new Error(error.message);
}
