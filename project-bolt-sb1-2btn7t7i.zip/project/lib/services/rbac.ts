import { supabase } from '@/lib/supabase';
import type { UserRole } from '@/lib/types';

export type Action = 'read' | 'create' | 'update' | 'delete' | 'manage' | 'export';

export interface Permission {
  resource: string;
  action: Action;
  scope: 'own' | 'institution' | 'all';
}

export async function getRolePermissions(role: UserRole): Promise<Permission[]> {
  const { data, error } = await supabase
    .from('role_permissions')
    .select('resource, action, scope')
    .eq('role', role);
  if (error) throw new Error(error.message);
  return (data || []).map((r) => ({ resource: r.resource, action: r.action as Action, scope: r.scope as 'own' | 'institution' | 'all' }));
}

export function hasPermission(
  permissions: Permission[],
  resource: string,
  action: Action,
  minScope?: 'own' | 'institution' | 'all'
): boolean {
  const matched = permissions.find((p) => p.resource === resource && p.action === action);
  if (!matched) return false;
  if (!minScope) return true;
  const scopeRank = { own: 1, institution: 2, all: 3 };
  return scopeRank[matched.scope] >= scopeRank[minScope];
}

export function hasAnyPermission(
  permissions: Permission[],
  resource: string,
  actions: Action[]
): boolean {
  return actions.some((action) => hasPermission(permissions, resource, action));
}

export function hasAllPermissions(
  permissions: Permission[],
  checks: { resource: string; action: Action }[]
): boolean {
  return checks.every((c) => hasPermission(permissions, c.resource, c.action));
}

export function isAdminRole(role: UserRole | null): boolean {
  return role === 'admin' || role === 'super_admin' || role === 'coordinator';
}

export function isTeacherRole(role: UserRole | null): boolean {
  return role === 'teacher';
}

export function isStudentRole(role: UserRole | null): boolean {
  return role === 'student' || role === 'guardian';
}
